package models;

public class ArtfRole {
}
