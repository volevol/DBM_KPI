package models;

public class Role {
}
