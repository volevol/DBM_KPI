package models;

public class Artifact {
}
