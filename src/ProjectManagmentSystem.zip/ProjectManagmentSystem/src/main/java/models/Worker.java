package models;

public class Worker {
}
